package game;
/**
@author Shivam Singhal
*/

public interface BoardController {
	
	public void updated(BoardModel m);
	
}
